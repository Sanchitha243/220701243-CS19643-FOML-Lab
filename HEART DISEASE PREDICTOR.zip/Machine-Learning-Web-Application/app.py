import numpy as np
from flask import Flask, request, render_template
import pickle

app = Flask(__name__)

model = pickle.load(open('models/model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    int_features = [float(x) for x in request.form.values()]
    features = [np.array(int_features)]
    prediction = model.predict(features)
    
    output = max(0, min(100, round(prediction[0], 2)))  # Ensure prediction is between 0-100%
    
    # Determine risk level and detailed health insights
    risk_level = ''
    if output < 10:
        risk_level = 'Low'
    elif output < 20:
        risk_level = 'Moderate'
    else:
        risk_level = 'High'
    
    biking_percent = int_features[0]
    smoking_percent = int_features[1]
    
    recommendations = []
    if smoking_percent > 10:
        recommendations.append('Consider implementing smoking cessation programs - Even a 10% reduction in smoking can significantly decrease heart disease risk')
    if biking_percent < 30:
        recommendations.append('Encourage more active transportation like biking - Regular cycling can improve cardiovascular health by up to 20%')
    if output > 15:
        recommendations.append('Regular health screenings are strongly recommended - Early detection can prevent 80% of heart disease cases')
    
    # Additional lifestyle recommendations
    recommendations.extend([
        'Maintain a balanced diet rich in omega-3 fatty acids and antioxidants',
        'Practice stress-reduction techniques like meditation or deep breathing exercises',
        'Ensure 7-9 hours of quality sleep each night for heart health'
    ])
    
    # Calculate health impact scores for visualization
    biking_impact = min(100, max(-100, (30 - biking_percent) * -2))  # Positive impact
    smoking_impact = min(100, max(-100, smoking_percent * -2))  # Negative impact
    
    return render_template('index.html',
                          prediction_text='Predicted heart disease percentage: {}% (Risk Level: {})'.format(output, risk_level),
                          recommendations=recommendations,
                          biking_impact=biking_impact,
                          smoking_impact=smoking_impact)

if __name__ == '__main__':
    app.run(debug=False)
